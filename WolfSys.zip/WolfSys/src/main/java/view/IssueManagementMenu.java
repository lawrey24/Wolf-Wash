package view;

import java.sql.SQLException;
import java.util.Scanner;

import controller.IssueManagementController;

public class IssueManagementMenu {
    private final IssueManagementController controller;

    public IssueManagementMenu(IssueManagementController c) {
        controller = c;
    }

    public void loginAndShow(Scanner in) {
        System.out.println("\n=== ADMIN ISSUE MANAGEMENT ===");
        System.out.print("Admin ID: ");
        String id = in.nextLine().trim();
        System.out.print("Password: ");
        String pw = in.nextLine();
        try {
            if (!controller.login(id, pw)) {
                System.out.println("Invalid administrator credentials.");
                return;
            }
            System.out.println("Admin login successful.");
            show(in);
        } catch (SQLException e) {
            System.out.println("Admin login error: " + e.getMessage());
        } finally {
            controller.logout();
        }
    }

    private void show(Scanner in) throws SQLException {
        while (true) {
            System.out.println(
                    "\n=== ISSUE MANAGEMENT ===\n1. View all issues\n2. Filter by status\n3. Update issue status\n4. Add progress note\n5. View issue history\n6. Notification log\n0. Logout");
            System.out.print("Choice: ");
            String ch = in.nextLine().trim();
            switch (ch) {
                case "1" -> list("ALL");
                case "2" -> {
                    System.out.println("1 Pending | 2 In Progress | 3 Resolved");
                    String f = in.nextLine().trim();
                    list(switch (f) {
                        case "1" -> "PENDING";
                        case "2" -> "IN_PROGRESS";
                        case "3" -> "RESOLVED";
                        default -> "ALL";
                    });
                }
                case "3" -> status(in);
                case "4" -> note(in);
                case "5" -> history(in);
                case "6" -> notifications();
                case "0" -> {
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void list(String filter) throws SQLException {
        var items = controller.list(filter);
        if (items.isEmpty())
            System.out.println("No issues recorded.");
        else
            items.forEach(System.out::println);
    }

    private int id(Scanner in) {
        System.out.print("Issue ID: ");
        try {
            return Integer.parseInt(in.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void status(Scanner in) {
        int id = id(in);
        System.out.println("1 Pending | 2 In Progress | 3 Resolved");
        String s = in.nextLine().trim();
        String state = switch (s) {
            case "1" -> "PENDING";
            case "2" -> "IN_PROGRESS";
            case "3" -> "RESOLVED";
            default -> null;
        };
        if (state == null) {
            System.out.println("Invalid status.");
            return;
        }
        System.out.print("Progress note (optional): ");
        String note = in.nextLine();
        try {
            controller.changeStatus(id, state, note);
            System.out.println("Issue status updated; notification record created.");
        } catch (Exception e) {
            System.out.println("Update failed: " + e.getMessage());
        }
    }

    private void note(Scanner in) {
        int id = id(in);
        System.out.print("Progress note: ");
        String note = in.nextLine();
        try {
            controller.addNote(id, note);
            System.out.println("Note saved.");
        } catch (Exception e) {
            System.out.println("Could not save note: " + e.getMessage());
        }
    }

    private void history(Scanner in) {
        int id = id(in);
        try {
            var h = controller.history(id);
            if (h.isEmpty())
                System.out.println("No history for this issue.");
            else
                h.forEach(System.out::println);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void notifications() {
        try {
            var n = controller.notifications();
            if (n.isEmpty())
                System.out.println("No notification records.");
            else {
                System.out.println("ID | Issue | Student | Message | Created | Status");
                n.forEach(a -> System.out.println(String.join(" | ", a)));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}