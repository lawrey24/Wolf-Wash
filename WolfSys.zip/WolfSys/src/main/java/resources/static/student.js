const studentId = sessionStorage.getItem("wolfwash_id") || "620173162";
document.getElementById("student-label").textContent = studentId;

document.getElementById("issue-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("issue-msg");
  msg.textContent = "";

  const payload = {
    studentId,
    slotId: document.getElementById("slotId").value || null,
    title: document.getElementById("title").value.trim(),
    description: document.getElementById("description").value.trim()
  };

  const res = await fetch("/api/issues", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await res.json();

  if (res.ok) {
    msg.className = "msg ok";
    msg.textContent = `Issue #${data.issueId} submitted (Status: ${data.status}).`;
    e.target.reset();
  } else {
    msg.className = "msg err";
    msg.textContent = data.error || "Failed to submit issue.";
  }
});

async function logout() {
  await fetch("/api/auth/logout", { method: "POST" });
  sessionStorage.clear();
  window.location.href = "/index.html";
}