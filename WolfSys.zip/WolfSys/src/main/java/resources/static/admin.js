document.getElementById("admin-label").textContent = sessionStorage.getItem("wolfwash_id") || "ADM001";

async function loadIssues() {
  const filter = document.getElementById("status-filter").value;
  const tbody = document.getElementById("issues-body");

  const res = await fetch(`/api/issues?status=${encodeURIComponent(filter)}`);
  if (res.status === 401) {
    window.location.href = "/index.html";
    return;
  }
  const issues = await res.json();

  if (!issues.length) {
    tbody.innerHTML = `<tr><td colspan="5">No issues found.</td></tr>`;
    return;
  }

  tbody.innerHTML = issues.map((i) => `
    <tr>
      <td>#${i.issueId}</td>
      <td>${i.studentName || ""} (${i.studentId})</td>
      <td><strong>${i.title}</strong><br><small>${i.description}</small></td>
      <td><span class="badge ${i.status}">${i.status}</span></td>
      <td>
        <select id="sel-${i.issueId}">
          <option value="PENDING" ${i.status === "PENDING" ? "selected" : ""}>PENDING</option>
          <option value="IN_PROGRESS" ${i.status === "IN_PROGRESS" ? "selected" : ""}>IN_PROGRESS</option>
          <option value="RESOLVED" ${i.status === "RESOLVED" ? "selected" : ""}>RESOLVED</option>
        </select>
        <input id="note-${i.issueId}" placeholder="Note (optional)" />
        <button class="action" onclick="saveStatus(${i.issueId})">Save</button>
      </td>
    </tr>
  `).join("");
}

async function saveStatus(issueId) {
  const status = document.getElementById(`sel-${issueId}`).value;
  const note = document.getElementById(`note-${issueId}`).value;

  const res = await fetch(`/api/issues/${issueId}/status`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status, note })
  });

  if (res.ok) {
    loadIssues();
  } else {
    const err = await res.json();
    alert(err.error || "Could not update status.");
  }
}

async function logout() {
  await fetch("/api/auth/logout", { method: "POST" });
  sessionStorage.clear();
  window.location.href = "/index.html";
}

loadIssues();