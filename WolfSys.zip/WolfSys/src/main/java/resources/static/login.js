let role = "student";

function setRole(newRole) {
  role = newRole;
  document.getElementById("tab-student").classList.toggle("active", role === "student");
  document.getElementById("tab-admin").classList.toggle("active", role === "admin");
  document.getElementById("id-label").textContent = role === "student" ? "Student ID" : "Admin ID";
  document.getElementById("userId").placeholder = role === "student" ? "e.g. 620173162" : "e.g. ADM001";
  document.getElementById("error-msg").textContent = "";
}

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("userId").value.trim();
  const password = document.getElementById("password").value;
  const errEl = document.getElementById("error-msg");
  errEl.textContent = "";

  const url = role === "student" ? "/api/auth/student/login" : "/api/auth/admin/login";
  const payload = role === "student" ? { studentId: id, password } : { adminId: id, password };

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      errEl.textContent = data.message || "Invalid credentials.";
      return;
    }
    sessionStorage.setItem("wolfwash_id", id);
    window.location.href = role === "student" ? "/student.html" : "/admin.html";
  } catch {
    errEl.textContent = "Server error. Make sure Spring Boot is running.";
  }
});