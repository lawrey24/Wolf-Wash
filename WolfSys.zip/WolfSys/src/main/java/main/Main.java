package main;

import java.sql.SQLException;
import java.util.Scanner;

import controller.AdminController;
import controller.BookingController;
import controller.IssueManagementController;
import controller.LoginController;
import dao.FeedbackDao;
import model.User;
import service.Cancelation;
import service.FeedbackService;
import view.AdminMenu;
import view.FeedbackView;
import view.IssueManagementMenu;
import view.StudentMenu;

public class Main {

    public static void main(String[] args) {

        // Create core application components
        LoginController loginController = new LoginController();
        BookingController bookingController = new BookingController(loginController);
        Cancelation cancelationService = new Cancelation();

        StudentMenu studentMenu = new StudentMenu(bookingController, cancelationService);

        AdminController adminController = new AdminController();
        AdminMenu adminMenu = new AdminMenu(adminController);

        IssueManagementMenu issueManagementMenu = new IssueManagementMenu(new IssueManagementController());

        // Create feedback module components
        FeedbackService feedbackService = new FeedbackService(new FeedbackDao());

        // Start the application
        try (Scanner scanner = new Scanner(System.in)) {

            FeedbackView feedbackView = new FeedbackView(feedbackService, scanner);
            boolean running = true;

            System.out.println("================================");
            System.out.println("       WELCOME TO WOLF WASH");
            System.out.println("================================");

            while (running) {

                System.out.println("\n========== MAIN MENU ==========");
                System.out.println("1. Student Login");
                System.out.println("2. Admin Login");
                System.out.println("3. Feedback Module");
                System.out.println("4. Admin Issue Management");
                System.out.println("5. Exit");

                System.out.print("\nChoose an option: ");

                String choice = scanner.nextLine().trim();

                switch (choice) {
                    case "1" -> {
                        System.out.print("Enter Student ID: ");
                        String studentId = scanner.nextLine().trim();

                        System.out.print("Enter Password: ");
                        String password = scanner.nextLine();

                        try {
                            boolean successful = loginController.login(studentId, password);

                            if (successful) {
                                System.out.println("\nLogin successful!");
                                System.out.println("Welcome to Wolf Wash!");

                                // Open the student menu
                                studentMenu.showMenu(
                                        scanner,
                                        loginController.getAuthenticatedStudentId()
                                );

                                // Log out after leaving the student menu
                                loginController.logout();

                                System.out.println("\nYou have been logged out.");
                            } else {
                                System.out.println("\nInvalid Student ID or password.");
                            }
                        } catch (SQLException e) {
                            System.out.println("Login error: " + e.getMessage());
                        }
                    }
                    case "2" -> adminMenu.showMenu(scanner);
                    case "3" -> runFeedbackModule(scanner, feedbackService, feedbackView);
                    case "4" -> issueManagementMenu.loginAndShow(scanner);
                    case "5" -> {
                        System.out.println("\nThank you for using Wolf Wash!");
                        running = false;
                    }
                    default -> System.out.println("Invalid option. Please choose 1, 2, 3, 4, or 5.");
                }
            }

            System.out.println("\nWolf Wash application closed.");
        }
    }

    private static void runFeedbackModule(Scanner input,
                                         FeedbackService service,
                                         FeedbackView view) {
        while (true) {
            try {
                System.out.println("\n=== Wolf Wash Feedback Module ===");
                System.out.print("User ID (or 0 to return): ");
                String id = input.nextLine().trim();
                if ("0".equals(id)) {
                    break;
                }

                System.out.print("Password: ");
                String password = input.nextLine();
                User user = service.login(id, password);

                if (user == null) {
                    System.out.println("Invalid ID or password.");
                } else {
                    view.show(user);
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
                System.out.println("Check the database settings and try again.");
            } catch (SecurityException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}