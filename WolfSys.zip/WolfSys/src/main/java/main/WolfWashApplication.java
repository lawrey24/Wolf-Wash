package com.wolfwash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WolfWashApplication {
    public static void main(String[] args) {
        SpringApplication.run(WolfWashApplication.class, args);
    }
}
