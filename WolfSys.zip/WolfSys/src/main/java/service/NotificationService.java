package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;

import dao.DatabaseConnection;
import model.TimeSlot;

public class NotificationService {

    private final EmailService emailService;

    public NotificationService() {
        this.emailService = new EmailService();
    }

    public NotificationService(EmailService emailService) {
        this.emailService = emailService;
    }

    public boolean notifyBookingConfirmed(String studentId, TimeSlot slot) {
        String resourceLabel = String.format("Slot #%d (Washer #%d & Dryer #%d)",
                slot.getSlotID(),
                slot.getMachineID(),
                slot.getDryerID()
        );

        String subject = "Wolf Wash Booking Confirmed - " + resourceLabel;
        String body = """
                Hello Student (%s),

                Your laundry reservation is confirmed:
                - Resource: %s
                - Date: %s
                - Time: %s - %s

                Please arrive on time and leave the machine clear when your cycle finishes.
                """.formatted(
                studentId,
                resourceLabel,
                slot.getSlotDate(),
                slot.getStartTime(),
                slot.getEndTime()
        );

        return sendAndLog(studentId, "BOOKING", subject, body);
    }

    public boolean notifyBookingCancelled(String studentId, TimeSlot slot) {
        String resourceLabel = String.format("Slot #%d (Washer #%d & Dryer #%d)",
                slot.getSlotID(),
                slot.getMachineID(),
                slot.getDryerID()
        );

        String subject = "Wolf Wash Reservation Cancelled - " + resourceLabel;
        String body = """
                Hello Student (%s),

                Your laundry reservation has been cancelled and the slot is now open:
                - Resource: %s
                - Date: %s
                - Time: %s - %s
                """.formatted(
                studentId,
                resourceLabel,
                slot.getSlotDate(),
                slot.getStartTime(),
                slot.getEndTime()
        );

        return sendAndLog(studentId, "CANCELLATION", subject, body);
    }

    public boolean notifyBookingRescheduled(
            String studentId, TimeSlot oldSlot, TimeSlot newSlot) {

        String newResourceLabel = newSlot.getMachineID() > 0
                ? "Washer #" + newSlot.getMachineID() + " (30 mins)"
                : "Dryer #" + newSlot.getDryerID() + " (60 mins)";

        String subject = "Wolf Wash Reservation Rescheduled";
        String body = """
                Hello Student (%s),

                Your laundry reservation has been rescheduled:
                - Previous Slot: %s (%s - %s)
                - New Resource: %s
                - New Date: %s
                - New Time: %s - %s
                """.formatted(
                studentId,
                oldSlot.getSlotDate(),
                oldSlot.getStartTime(),
                oldSlot.getEndTime(),
                newResourceLabel,
                newSlot.getSlotDate(),
                newSlot.getStartTime(),
                newSlot.getEndTime()
        );

        return sendAndLog(studentId, "RESCHEDULE", subject, body);
    }

    public boolean notifySlotReminder(String studentId, TimeSlot slot) {
        String resourceLabel = slot.getMachineID() > 0
                ? "Washer #" + slot.getMachineID()
                : "Dryer #" + slot.getDryerID();

        String subject = "Wolf Wash Reminder: Upcoming Slot on " + slot.getSlotDate();
        String body = """
                Hello Student (%s),

                Reminder: Your laundry slot starts soon:
                - Resource: %s
                - Date: %s
                - Time: %s - %s
                """.formatted(
                studentId,
                resourceLabel,
                slot.getSlotDate(),
                slot.getStartTime(),
                slot.getEndTime()
        );

        return sendAndLog(studentId, "REMINDER", subject, body);
    }

    private boolean sendAndLog(
            String studentId, String type, String subject, String body) {

        String recipientEmail = getStudentEmail(studentId);
        String status = "SENT";
        String errorMessage = null;
        Timestamp sentAt = Timestamp.from(Instant.now());

        if (recipientEmail == null || recipientEmail.isBlank()) {
            recipientEmail = "unknown@unknown.local";
            status = "FAILED";
            errorMessage = "Student email not found in database.";
            sentAt = null;
        } else {
            try {
                emailService.sendEmail(recipientEmail, subject, body);
            } catch (Exception ex) {
                status = "FAILED";
                errorMessage = truncate(ex.getMessage(), 250);
                sentAt = null;
            }
        }

        logNotification(
                studentId, recipientEmail, type, subject, body, status, errorMessage, sentAt);

        return "SENT".equals(status);
    }

    private String getStudentEmail(String studentId) {
        String sql = "SELECT email FROM students WHERE student_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("email");
                }
            }
        } catch (SQLException ignored) {
            // Handled cleanly as missing email
        }
        return null;
    }

    private void logNotification(
            String studentId,
            String recipientEmail,
            String type,
            String subject,
            String body,
            String status,
            String errorMessage,
            Timestamp sentAt) {

        String sql = """
                INSERT INTO notification_log
                    (student_id, recipient_email, notification_type, subject, body, status, error_message, sent_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);
            stmt.setString(2, recipientEmail);
            stmt.setString(3, type);
            stmt.setString(4, subject);
            stmt.setString(5, body);
            stmt.setString(6, status);
            stmt.setString(7, errorMessage);
            stmt.setTimestamp(8, sentAt);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Failed to write notification_log entry: " + ex.getMessage());
        }
    }

    private String truncate(String value, int maxLen) {
        if (value == null) {
            return "Unknown email error";
        }
        return value.length() <= maxLen ? value : value.substring(0, maxLen);
    }
}