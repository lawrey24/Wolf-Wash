package service;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailService {

    private final String host;
    private final String port;
    private final String username;
    private final String appPassword;
    private final String fromAddress;

    public EmailService() {
        this.host = System.getenv().getOrDefault("WOLF_WASH_SMTP_HOST", "smtp.gmail.com");
        this.port = System.getenv().getOrDefault("WOLF_WASH_SMTP_PORT", "587");
        this.username = System.getenv("WOLF_WASH_SMTP_USER");
        this.appPassword = System.getenv("WOLF_WASH_SMTP_PASS");
        this.fromAddress = System.getenv().getOrDefault(
                "WOLF_WASH_FROM_EMAIL",
                this.username != null ? this.username : "noreply@wolfwash.local"
        );
    }

    public void sendEmail(String toAddress, String subject, String body)
            throws MessagingException {

        if (toAddress == null || toAddress.isBlank()) {
            throw new IllegalArgumentException("Recipient email address is missing.");
        }

        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session;
        if (username != null && !username.isBlank() && appPassword != null && !appPassword.isBlank()) {
            session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, appPassword);
                }
            });
        } else {
            session = Session.getInstance(props);
        }

        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromAddress));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress));
        message.setSubject(subject);
        message.setText(body);

        Transport.send(message);
    }
}