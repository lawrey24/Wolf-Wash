package controller;

import java.sql.SQLException;
import java.util.List;

import model.IssueUpdate;
import model.ReportedIssue;
import service.IssueManagementService;

public class IssueManagementController {
    private final IssueManagementService service;
    private String adminId;

    public IssueManagementController() {
        this.service = new IssueManagementService();
        this.adminId = null;
    }

    public IssueManagementController(IssueManagementService service) {
        this.service = service != null ? service : new IssueManagementService();
        this.adminId = null;
    }

    public boolean login(String id, String password) throws SQLException {
        adminId = null;
        if (id == null || password == null) {
            return false;
        }
        String trimmedId = id.trim();
        if (trimmedId.isEmpty() || password.isEmpty()) {
            return false;
        }
        if (service.login(trimmedId, password)) {
            adminId = trimmedId;
            return true;
        }
        return false;
    }

    public void logout() {
        adminId = null;
    }

    private void requireLogin() {
        if (adminId == null) {
            throw new IllegalStateException("Please log in as an administrator.");
        }
    }

    public String getAdminId() {
        return adminId;
    }

    public List<ReportedIssue> list(String filter) throws SQLException {
        requireLogin();
        return service.list(filter);
    }

    public ReportedIssue get(int id) throws SQLException {
        requireLogin();
        return service.get(id);
    }

    public List<IssueUpdate> history(int id) throws SQLException {
        requireLogin();
        return service.history(id);
    }

    public List<String[]> notifications() throws SQLException {
        requireLogin();
        return service.notifications();
    }

    public void changeStatus(int id, String status, String note) throws SQLException {
        requireLogin();
        service.changeStatus(id, adminId, status, note);
    }

    public void addNote(int id, String note) throws SQLException {
        requireLogin();
        service.addNote(id, adminId, note);
    }
}