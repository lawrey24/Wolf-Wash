package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import model.IssueUpdate;
import model.ReportedIssue;

public class ReportedIssueDAO {

    private static final String BASE_SELECT = """
            SELECT i.issue_id, i.student_id, s.full_name, i.title, i.description,
                   i.status, i.created_at, i.updated_at
            FROM reported_issues i
            JOIN students s ON s.student_id = i.student_id
            """;

    public List<ReportedIssue> getAll() throws SQLException {
        String sql = BASE_SELECT + " ORDER BY i.created_at DESC";
        List<ReportedIssue> out = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {
            while (r.next()) {
                out.add(map(r));
            }
        }
        return out;
    }

    public List<ReportedIssue> getByStatus(String status) throws SQLException {
        String sql = BASE_SELECT + " WHERE i.status = ? ORDER BY i.created_at DESC";
        List<ReportedIssue> out = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, status);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    out.add(map(r));
                }
            }
        }
        return out;
    }

    private ReportedIssue map(ResultSet r) throws SQLException {
        Timestamp created = r.getTimestamp("created_at");
        Timestamp updated = r.getTimestamp("updated_at");
        LocalDateTime createdAt = created == null ? null : created.toLocalDateTime();
        LocalDateTime updatedAt = updated == null ? createdAt : updated.toLocalDateTime();
        return new ReportedIssue(
                r.getInt("issue_id"),
                r.getString("student_id"),
                r.getString("full_name"),
                r.getString("title"),
                r.getString("description"),
                r.getString("status"),
                createdAt,
                updatedAt
        );
    }

    public ReportedIssue getById(int id) throws SQLException {
        String sql = BASE_SELECT + " WHERE i.issue_id = ?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? map(r) : null;
            }
        }
    }

    public void addUpdate(int issueId, String adminId, String oldStatus, String newStatus, String note)
            throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            boolean previousAutoCommit = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                String upd = "UPDATE reported_issues SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE issue_id = ?";
                try (PreparedStatement p = c.prepareStatement(upd)) {
                    p.setString(1, newStatus);
                    p.setInt(2, issueId);
                    p.executeUpdate();
                }

                String log = """
                        INSERT INTO issue_updates (issue_id, admin_id, old_status, new_status, note)
                        VALUES (?, ?, ?, ?, ?)
                        """;
                try (PreparedStatement p = c.prepareStatement(log)) {
                    p.setInt(1, issueId);
                    p.setString(2, adminId);
                    p.setString(3, oldStatus);
                    p.setString(4, newStatus);
                    p.setString(5, note);
                    p.executeUpdate();
                }

                String notif = """
                        INSERT INTO issue_notifications (issue_id, student_id, message)
                        SELECT issue_id, student_id, ?
                        FROM reported_issues
                        WHERE issue_id = ?
                        """;
                try (PreparedStatement p = c.prepareStatement(notif)) {
                    String msg = "Your issue #" + issueId + " was updated: " + newStatus
                            + (note.isBlank() ? "" : " - " + note);
                    p.setString(1, msg);
                    p.setInt(2, issueId);
                    p.executeUpdate();
                }

                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(previousAutoCommit);
            }
        }
    }

    public void addNote(int issueId, String adminId, String note) throws SQLException {
        String sql = """
                INSERT INTO issue_updates (issue_id, admin_id, old_status, new_status, note)
                VALUES (?, ?, NULL, NULL, ?)
                """;
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, issueId);
            p.setString(2, adminId);
            p.setString(3, note);
            p.executeUpdate();
        }
    }

    public List<IssueUpdate> history(int issueId) throws SQLException {
        String sql = """
                SELECT update_id, issue_id, admin_id, old_status, new_status, note, created_at
                FROM issue_updates
                WHERE issue_id = ?
                ORDER BY created_at
                """;
        List<IssueUpdate> out = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, issueId);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    Timestamp created = r.getTimestamp(7);
                    out.add(new IssueUpdate(
                            r.getInt(1),
                            r.getInt(2),
                            r.getString(3),
                            r.getString(4),
                            r.getString(5),
                            r.getString(6),
                            created == null ? null : created.toLocalDateTime()
                    ));
                }
            }
        }
        return out;
    }

    public List<String[]> notifications() throws SQLException {
        String sql = """
                SELECT notification_id, issue_id, student_id, message, created_at, delivery_status
                FROM issue_notifications
                ORDER BY created_at DESC
                """;
        List<String[]> out = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {
            while (r.next()) {
                out.add(new String[]{
                        r.getString(1),
                        r.getString(2),
                        r.getString(3),
                        r.getString(4),
                        r.getString(5),
                        r.getString(6)
                });
            }
        }
        return out;
    }
}